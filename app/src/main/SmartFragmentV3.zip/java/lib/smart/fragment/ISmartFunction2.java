package lib.smart.fragment;

/**
 * Created by Augustine on 2018/5/14.
 * <p>
 * email:nice_ohoh@163.com
 */

public interface ISmartFunction2 {

    void startFragment(SmartFragment start);

    void startFragmentCloseSelf(SmartFragment start);

    void startFragmentNoAnim(SmartFragment start);

    void startFragmentCloseSelfNoAnim(SmartFragment start);

}
