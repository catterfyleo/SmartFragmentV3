package lib.smart.fragment;

/**
 * Created by Augustine on 2018/5/14.
 * <p>
 * email:nice_ohoh@163.com
 */

public interface ICommitCallBack {

    void onCommit(SmartFragment fragment);

}
